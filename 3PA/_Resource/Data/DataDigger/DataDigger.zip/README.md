# DataDigger
A dynamic dataviewer for your Progress / OpenEdge databases
